export interface EditProductRequest {
  name: string;
  price: string;
  description: string;
  product_id: string;
  amount: number;
  category_id: string;
}
