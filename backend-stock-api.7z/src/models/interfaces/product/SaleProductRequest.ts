export interface SaleProductRequest {
  product_id: string;
  amount: number;
}
