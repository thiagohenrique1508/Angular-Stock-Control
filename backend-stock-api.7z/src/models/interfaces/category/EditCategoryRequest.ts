export interface EditCategoryRequest {
  name: string;
  category_id: string;
}
